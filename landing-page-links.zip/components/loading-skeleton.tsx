export default function LoadingSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <main className="container mx-auto px-4 py-8 max-w-md">
        {/* Profile Skeleton */}
        <div className="text-center mb-8">
          <div className="w-32 h-32 mx-auto bg-white/20 rounded-full animate-pulse mb-6"></div>
          <div className="flex justify-center gap-6 mb-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="w-12 h-12 bg-white/20 rounded-full animate-pulse"></div>
            ))}
          </div>
        </div>

        {/* Links Skeleton */}
        <div className="space-y-6">
          {[1, 2].map((section) => (
            <div key={section}>
              <div className="h-6 bg-white/20 rounded mx-auto w-32 mb-4 animate-pulse"></div>
              <div className="space-y-3">
                {[1, 2, 3].map((link) => (
                  <div key={link} className="h-14 bg-white/10 rounded-xl animate-pulse"></div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
