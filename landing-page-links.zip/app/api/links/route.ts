import { NextResponse } from "next/server"

export async function GET() {
  // Aqui você pode conectar com um banco de dados ou CMS
  // Por enquanto, retornando dados estáticos
  const links = [
    {
      section: "Principais Links",
      items: [
        { title: "🏠 Site Principal", url: "https://example.com" },
        { title: "🛒 Loja Online", url: "https://shop.example.com" },
        { title: "📝 Blog", url: "https://blog.example.com" },
        { title: "🎵 Playlist Spotify", url: "https://spotify.com" },
      ],
    },
    {
      section: "Redes Sociais",
      items: [
        { title: "📸 Instagram Stories", url: "https://www.instagram.com/liraa_grau_oficial" },
        { title: "🎬 Últimos Vídeos TikTok", url: "https://www.tiktok.com/@liraa_grau_oficial" },
        { title: "▶️ Canal YouTube", url: "https://www.youtube.com/@liraa_grau_oficiall" },
      ],
    },
    {
      section: "Contato",
      items: [
        { title: "💬 WhatsApp", url: "https://wa.me/5511999999999" },
        { title: "📧 Email", url: "mailto:contato@liraagrau.com" },
        { title: "📞 Agendamento", url: "https://calendly.com/liraagrau" },
      ],
    },
  ]

  return NextResponse.json(links)
}
