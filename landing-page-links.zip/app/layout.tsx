import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Liraa Grau Oficial - Links",
  description: "Todos os links importantes do Liraa Grau Oficial em um só lugar",
  keywords: ["liraa grau", "links", "redes sociais", "contato"],
  openGraph: {
    title: "Liraa Grau Oficial - Links",
    description: "Todos os links importantes em um só lugar",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
