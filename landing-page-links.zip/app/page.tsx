import Image from "next/image"
import { Instagram, Youtube } from "lucide-react"

interface LinkItem {
  title: string
  url: string
}

interface LinkSection {
  section: string
  items: LinkItem[]
}

async function getLinks(): Promise<LinkSection[]> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/api/links`, {
      cache: "no-store",
    })
    if (!res.ok) throw new Error("Failed to fetch links")
    return res.json()
  } catch (error) {
    // Fallback data in case API fails
    return [
      {
        section: "Principais Links",
        items: [
          { title: "Meu Site Principal", url: "https://example.com" },
          { title: "Loja Online", url: "https://shop.example.com" },
          { title: "Blog", url: "https://blog.example.com" },
        ],
      },
      {
        section: "Contato",
        items: [
          { title: "WhatsApp", url: "https://wa.me/5511999999999" },
          { title: "Email", url: "mailto:contato@example.com" },
        ],
      },
    ]
  }
}

export default async function HomePage() {
  const links = await getLinks()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <main className="container mx-auto px-4 py-8 max-w-md">
        {/* Profile Section */}
        <div className="text-center mb-8">
          <div className="profile-pic-wrapper mb-6">
            <div className="relative w-32 h-32 mx-auto">
              <Image
                src="/imgs/perfil.PNG"
                alt="Foto de Perfil"
                fill
                className="rounded-full object-cover border-4 border-white shadow-lg"
              />
            </div>
          </div>

          {/* Social Icons */}
          <div className="flex justify-center gap-6 mb-8">
            <a
              href="https://www.instagram.com/liraa_grau_oficial?igsh=MWI2Mmg5M2MwZm1ieA=="
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-300 hover:scale-110"
            >
              <Instagram className="w-6 h-6 text-white" />
            </a>
            <a
              href="https://www.tiktok.com/@liraa_grau_oficial?_t=ZM-8xvMyob4oAK&_r=1"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-300 hover:scale-110"
            >
              <div className="w-6 h-6 text-white flex items-center justify-center font-bold text-sm">TT</div>
            </a>
            <a
              href="https://www.youtube.com/@liraa_grau_oficiall?si=9jmDG4U8PHrHFSgW"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-300 hover:scale-110"
            >
              <Youtube className="w-6 h-6 text-white" />
            </a>
          </div>
        </div>

        {/* Links Sections */}
        <div className="space-y-6">
          {links.map((section, sectionIndex) => (
            <div key={sectionIndex} className="section-block">
              <h2 className="text-xl font-bold text-white text-center mb-4">{section.section}</h2>
              <div className="space-y-3">
                {section.items.map((link, linkIndex) => (
                  <a
                    key={linkIndex}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full p-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white text-center font-medium hover:bg-white/20 hover:scale-105 transition-all duration-300 hover:shadow-lg"
                  >
                    {link.title}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-white/60 text-sm">
          <p>© 2024 Liraa Grau Oficial</p>
        </div>
      </main>
    </div>
  )
}
