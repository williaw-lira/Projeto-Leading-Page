fetch('/api/links')
  .then(res => res.json())
  .then(data => {
    const select = document.getElementById('sectionSelect');
    data.forEach(section => {
      const opt = document.createElement('option');
      opt.value = section.section;
      opt.textContent = section.section;
      select.appendChild(opt);
    });
  });

function addSection() {
  const name = document.getElementById('sectionName').value;
  fetch('/api/section', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name })
  }).then(() => location.reload());
}

function addLink() {
  const section = document.getElementById('sectionSelect').value;
  const title = document.getElementById('linkTitle').value;
  const url = document.getElementById('linkUrl').value;

  fetch('/api/links', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ section, title, url })
  }).then(() => location.reload());
}
